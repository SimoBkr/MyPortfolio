BKR SECURITY Android App
* Setup 
-Pour lancé le projet projet Web "Ronde_Backend" Réalisé Avec Spring boot, vous aurez besoin de la dernière version de Java 8 
-Vous aurez besoin d'une version plus récente, 3.1, d'Apache Maven installée.
-Vous aurez besoin d'un IDE installé. Quelque chose comme Apache NetBeans, Eclipse ou IntelliJ IDE(recommandé).
- Lancé le projet Ronde_Backend avec votre IDE.
-Lancé le Fichier Script.sql dans MysqlWorkbench ou n'importe quelle plateforme de Mysql le Script contient juste la creation de la base de donné les tables ca sera créer automatique Quand vous lancé le projet Web.
-Ouvrir le Terminal de IDE est ecrire : "mvn spring-boot:run"
vérifier que vous etes dans le fichier de projet .
- Quand le projet terminé Lancé le Projet Android avec Android Studio .
- vérifier que votre SDK est > 24 .
- connécter avec le compte admin .
email = m@m
password = m@m