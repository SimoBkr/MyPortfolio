package com.example.ronde;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataHelper extends SQLiteOpenHelper {

    public static final String LOGIN_TABLE_NAME = "Login";
    public static final String EMAIL = "email";
    public static final String PASSWORD = "password";

    private static final String LOGIN_TABLE_CREATE ="CREATE TABLE "+LOGIN_TABLE_NAME+
            "("+EMAIL+" TEXT ,"+PASSWORD+" TEXT);";
    private static final String DATABASE_NAME ="appdatas" ;
    private static final int DATABASE_VERSION = 1;

    public DataHelper(Context context) {
        super(context , DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
            db.execSQL(LOGIN_TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS "+LOGIN_TABLE_NAME);
        onCreate(db);
    }
}
