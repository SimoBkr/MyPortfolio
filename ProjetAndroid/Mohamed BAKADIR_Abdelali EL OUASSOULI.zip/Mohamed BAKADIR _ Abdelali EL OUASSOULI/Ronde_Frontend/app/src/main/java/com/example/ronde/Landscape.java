package com.example.ronde;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.JsonArray;

import org.json.JSONArray;
import org.json.JSONObject;

public class Landscape implements Parcelable {

    private int id ;
    private int imageID ;
    private String title ;
    private String desciption ;
    private String email ;
    private String role;
    private String last_name;
    private String first_name;
    private String password ;
    private String date_rec ;
    private JSONArray listPassage;


    public JSONArray getListPassage() {
        return listPassage;
    }

    public void setListPassage(JSONArray listPassage) {
        this.listPassage = listPassage;
    }

    public Landscape(String title, String desciption, String last_name, String first_name, JSONArray listPassage) {
        this.title = title;
        this.desciption = desciption;
        this.last_name = last_name;
        this.first_name = first_name;
        this.listPassage = listPassage;
    }

    public Landscape(int id, int imageID, String title, String desciption, String email, String role, String last_name, String first_name, String password, String date_rec, JSONArray listPassage) {
        this.id = id;
        this.imageID = imageID;
        this.title = title;
        this.desciption = desciption;
        this.email = email;
        this.role = role;
        this.last_name = last_name;
        this.first_name = first_name;
        this.password = password;
        this.date_rec = date_rec;
        this.listPassage = listPassage;
    }

    public Landscape() {
    }

    public Landscape(int id, String email, String role, String last_name, String first_name, String password, String date_rec) {
        this.id = id;
        this.email = email;
        this.role = role;
        this.last_name = last_name;
        this.first_name = first_name;
        this.password = password;
        this.date_rec = date_rec;
    }

    public Landscape(int imageID, String title, String desciption) {
        this.imageID = imageID;
        this.title = title;
        this.desciption = desciption;
    }

    public Landscape(int id, String title) {
        this.id = id;
        this.title = title;
    }

    protected Landscape(Parcel in) {
        id = in.readInt();
        imageID = in.readInt();
        title = in.readString();
        desciption = in.readString();
        email = in.readString();
        role = in.readString();
        last_name = in.readString();
        first_name = in.readString();
        password = in.readString();
        date_rec = in.readString();
    }

    public static final Creator<Landscape> CREATOR = new Creator<Landscape>() {
        @Override
        public Landscape createFromParcel(Parcel in) {
            return new Landscape(in);
        }

        @Override
        public Landscape[] newArray(int size) {
            return new Landscape[size];
        }
    };

    public String getDate_rec() {
        return date_rec;
    }

    public void setDate_rec(String date_rec) {
        this.date_rec = date_rec;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getImageID() {
        return imageID;
    }

    public void setImageID(int imageID) {
        this.imageID = imageID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {this.title = title;}

    public String getDesciption() {return desciption;}

    public void setDesciption(String desciption) {this.desciption = desciption;}


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeInt(imageID);
        dest.writeString(title);
        dest.writeString(desciption);
        dest.writeString(email);
        dest.writeString(role);
        dest.writeString(last_name);
        dest.writeString(first_name);
        dest.writeString(password);
        dest.writeString(date_rec);
    }
}
