package com.example.ronde;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.ronde.model.MySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class RecyclerAdapterCapteur extends RecyclerView.Adapter<RecyclerAdapterCapteur.MyViewHolderse> {

        private List<Landscape> myData ;
        private LayoutInflater mInflater;

        private Context context ;

    public RecyclerAdapterCapteur(Context context , List<Landscape> data) {
        this.myData = data;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
    }


    @NonNull
    @Override
    public MyViewHolderse onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Log.d("Simo","onCreateViewHolder");
        View view = mInflater.inflate(R.layout.list_item_capteur,parent,false);
        MyViewHolderse myViewHolderse = new MyViewHolderse(view);
        return myViewHolderse;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolderse holder, int position) {
        Log.d("Simo","onBindeViewHolder"+position);
        Landscape currentObj = myData.get(position);
        holder.setData(currentObj,position);
        holder.setListner();
    }

    @Override
    public int getItemCount() {
        return myData.size();
    }


    public void removeItem(int position) {

        int id =myData.get(position).getId();
        String URL = "http://192.168.1.7:8080/captures/"+myData.get(position).getId()+"";
        RequestQueue queue = MySingleton.getInstance(this.context).getRequestQueue();
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.DELETE, URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                JSONObject personne = null;
                try {
                    personne = response.getJSONObject("personne");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        MySingleton.getInstance(this.context).addToRequestQueue(jsonObjectRequest);
        myData.remove(position);
        Toast.makeText(context, "Capteur :"+myData.get(position).getTitle().toString()+" a été Supprimer", Toast.LENGTH_SHORT).show();
        notifyItemRemoved(position);

    }

    public void updateItem(int position) {
        int idcap = myData.get(position).getId();
        String MacAdresse = myData.get(position).getTitle().toString();

        Landscape landscapecap = new Landscape(idcap,MacAdresse);

        Intent intent = new Intent(context,UpdateCapteur.class);
        intent.putExtra("myCapteur",landscapecap);
        context.startActivity(intent);

    }

    class MyViewHolderse extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView title , description;
        ImageView imgProfile,imgDelete,imgAdd;
        int position;
        Landscape current ;

        public MyViewHolderse( View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.titlee);
            description = itemView.findViewById(R.id.descriptionn);
            imgProfile = itemView.findViewById(R.id.imgProfileee);
            imgDelete = itemView.findViewById(R.id.imgDelete);
            imgAdd = itemView.findViewById(R.id.imgadd);
        }



        public void setData(Landscape current , int position) {
            this.title.setText(current.getTitle());
            this.description.setText(current.getDesciption());
            this.imgProfile.setImageResource(current.getImageID());
            this.position = position;
            this.current = current;
        }

        public void setListner() {
            imgDelete.setOnClickListener(MyViewHolderse.this);
            imgAdd.setOnClickListener(MyViewHolderse.this);
        }

        @Override
        public void onClick(View v) {
            switch(v.getId()){
                case R.id.imgDelete : removeItem(position); break;
                case R.id.imgadd : updateItem(position); break;
            }
        }
    }

}



