package com.example.ronde;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.ronde.model.MySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class RecyclerAdapterofagent extends RecyclerView.Adapter<RecyclerAdapterofagent.MyViewHolder> {

        private List<Landscape> mData ;
        private LayoutInflater mInflater;
        private Context context ;

    public RecyclerAdapterofagent(Context context , List<Landscape> data) {
        this.mData = data;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Log.d("Simo","onCreateViewHolder");
        View view = mInflater.inflate(R.layout.list_item_passage_of_agent,parent,false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Log.d("Simo","onBindeViewHolder"+position);
        Landscape currentObj = mData.get(position);
        holder.setData(currentObj,position);
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }


    class MyViewHolder extends RecyclerView.ViewHolder  {

        TextView title , description;
        ImageView imgProfile ,imgPassage;
        int position;
        Landscape current ;

        public MyViewHolder( View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.titlepassageofagent);
            description = itemView.findViewById(R.id.descriptiopassageofagent);
            imgProfile = itemView.findViewById(R.id.imgProfilpassageofagent);
            imgPassage = itemView.findViewById(R.id.imgPassage);
        }


        public void setData(Landscape current , int position) {
            this.title.setText(current.getTitle());
            this.description.setText(current.getDesciption());
            this.imgProfile.setImageResource(current.getImageID());
            this.position = position;
            this.current = current;
        }

    }



}



