package com.example.ronde;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.ronde.model.MySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Random;

public class ListeofPassage extends AppCompatActivity {

    Landscape landscape ;
    ArrayList<Landscape> dataList ;
     private Toolbar toolbar;
     String all_name ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listeof_passage);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpRecycleView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        Intent intent ;
        switch (item.getItemId()){

            case R.id.HomeItem :
                intent = new Intent(getApplicationContext(),ListeofPlannings.class);
                startActivity(intent);
                break;

            case R.id.AddagentItem :
                intent = new Intent(getApplicationContext(),AddPersonne.class);
                startActivity(intent);
                break;

            case R.id.addplanningtoagentItem :
                intent = new Intent(getApplicationContext(),activity_planning.class);
                startActivity(intent);
                break;

            case R.id.addcapture :
                intent = new Intent(getApplicationContext(),AddCaptureActivity.class);
                startActivity(intent);
                break;

            case R.id.cap :
                intent = new Intent(getApplicationContext(),ListeCapteur.class);
                startActivity(intent);
                break;

            case R.id.listPassage :
                intent = new Intent(getApplicationContext(),ListeofPassage.class);
                startActivity(intent);
                break;

            case R.id.Logout :
                intent = new Intent(getApplicationContext(),LoginPersonne.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setUpRecycleView() {
        String URL = "http://192.168.1.7:8080/passages";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, URL, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                dataList = new ArrayList<>();
                Random r = new Random();
                JSONObject passage = null;
                JSONObject agent = null;
                for(int i=0 ; i< response.length();i++){
                    landscape = new Landscape();
                    try {
                        //MyAsck myAsck = new MyAsck();
                        passage = response.getJSONObject(i);
                        int[] images = {R.drawable.couloire};
                        landscape.setImageID(images[0]);

                        landscape.setDesciption(passage.getString("capteur").toString() +" "+
                                passage.getString("date").toString());
                        landscape.setId(passage.getInt("id"));

                        agent =  passage.getJSONObject("agent");

                        landscape.setTitle(agent.getString("firstName")+" "+agent.getString("lastName"));

                        dataList.add(landscape);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                RecyclerView myrec = (RecyclerView) findViewById(R.id.recycleViewPassage);
                RecyclerAdapterPassage mycrecycapteur = new RecyclerAdapterPassage(getApplicationContext(),dataList);
                myrec.setAdapter(mycrecycapteur);

                LinearLayoutManager linearm = new LinearLayoutManager(getApplicationContext());
                linearm.setOrientation(LinearLayoutManager.VERTICAL);
                myrec.setLayoutManager(linearm);

                myrec.setItemAnimator(new DefaultItemAnimator());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

//    public  class  MyAsck extends AsyncTask<Integer,Integer,String>{
//
//        @Override
//        protected String doInBackground(Integer... integers) {
//            String URL = "http://192.168.1.7:8080/personnes/"+integers[0];
//            JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, URL, null, new Response.Listener<JSONArray>() {
//                @Override
//                public void onResponse(JSONArray response) {
//                    for(int i=0;i<response.length();i++){
//                        try {
//                            JSONObject personne = response.getJSONObject(i);
//                            String firsName = personne.getString("firstName");
//                            String lastName = personne.getString("lastName");
//                            all_name = firsName+" "+lastName;
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//
//                    }
//                }
//            }, new Response.ErrorListener() {
//                @Override
//                public void onErrorResponse(VolleyError error) {
//
//                }
//            });
//            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
//            requestQueue.add(jsonArrayRequest);
//
//            return all_name;
//        }
//
//        @Override
//        protected void onPostExecute(String s) {
//            super.onPostExecute(s);
//
//            Toast.makeText(ListeofPassage.this, s+"", Toast.LENGTH_SHORT).show();
//
//        }
//    }

}