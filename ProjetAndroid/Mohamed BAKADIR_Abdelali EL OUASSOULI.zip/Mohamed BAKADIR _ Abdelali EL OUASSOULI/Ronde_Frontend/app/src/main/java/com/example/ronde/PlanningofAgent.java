package com.example.ronde;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.ronde.model.Personne;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class PlanningofAgent extends AppCompatActivity {

    Landscape landscapee ;
    ArrayList<Landscape> dataListe ;
    String All_planning ;
    String All_dates ;
    String All_horaire ;
    static Personne myagent ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planningof_agent);
        Intent intent = getIntent();
         myagent = intent.getParcelableExtra("myagent");
         All_planning = intent.getStringExtra("Planningofagent");
         All_dates = intent.getStringExtra("datesofagents");
        All_horaire = intent.getStringExtra("Listhoraire");
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpRecycleView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_all,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        Intent intent ;
        switch (item.getItemId()){

            case R.id.HomeItem :
                intent = new Intent(getApplicationContext(),PlanningofAgent.class);
                startActivity(intent);
                break;

            case R.id.mypassage :
                intent = new Intent(getApplicationContext(),ListeofPassage.class);
                startActivity(intent);
                break;

            case R.id.Logout :
                intent = new Intent(getApplicationContext(),LoginPersonne.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setUpRecycleView() {
                dataListe = new ArrayList<>();
                String plans[] = All_planning.split("_");
                String dates[] = All_dates.split("_");
                String horaires[] = All_horaire.split("_");
                int[] images = {R.drawable.time};
                for(int i=0;i<plans.length;i++){
                    landscapee = new Landscape();

                        landscapee.setImageID(images[0]);
                        landscapee.setTitle(plans[i].toString());
                        String heureandminut [] = horaires[i].toString().split(":");
                        landscapee.setDesciption(dates[i].toString()+" a "+heureandminut[0].toString()+"h:"+heureandminut[1].toString()+"mm");

                        dataListe.add(landscapee);

                }

                RecyclerView recyclerVieww = (RecyclerView) findViewById(R.id.recycleViewplanning);
                RecyclerAdapterPlanning adapterr  = new RecyclerAdapterPlanning(getApplicationContext(),dataListe);
                recyclerVieww.setAdapter(adapterr);

                LinearLayoutManager linearLayoutManagerr = new LinearLayoutManager(getApplicationContext());
                linearLayoutManagerr.setOrientation(LinearLayoutManager.VERTICAL);
                recyclerVieww.setLayoutManager(linearLayoutManagerr);

                recyclerVieww.setItemAnimator(new DefaultItemAnimator());

            }

}