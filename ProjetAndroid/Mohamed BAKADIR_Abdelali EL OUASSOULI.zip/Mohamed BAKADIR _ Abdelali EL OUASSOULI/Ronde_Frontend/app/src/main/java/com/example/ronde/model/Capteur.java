package com.example.ronde.model;


import java.util.List;


public class Capteur {

    private Long Id;
    private String SerialNumber;


    public Capteur(Long id, String serialNumber) {
        Id = id;
        SerialNumber = serialNumber;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public Capteur() {
    }

    public String getSerialNumber() {
        return SerialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        SerialNumber = serialNumber;
    }
}
