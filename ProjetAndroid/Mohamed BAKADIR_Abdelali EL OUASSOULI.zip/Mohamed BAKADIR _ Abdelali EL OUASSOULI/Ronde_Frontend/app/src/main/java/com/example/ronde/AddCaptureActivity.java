package com.example.ronde;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

public class AddCaptureActivity extends AppCompatActivity {

    EditText serialNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_capture);

        serialNumber = findViewById(R.id.SerialNummber);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        Intent intent ;
        switch (item.getItemId()){

            case R.id.HomeItem :
                intent = new Intent(getApplicationContext(),ListeofPlannings.class);
                startActivity(intent);
                break;

            case R.id.AddagentItem :
                intent = new Intent(getApplicationContext(),AddPersonne.class);
                startActivity(intent);
                break;

            case R.id.addplanningtoagentItem :
                intent = new Intent(getApplicationContext(),activity_planning.class);
                startActivity(intent);
                break;

            case R.id.addcapture :
                intent = new Intent(getApplicationContext(),AddCaptureActivity.class);
                startActivity(intent);
                break;

            case R.id.cap :
                intent = new Intent(getApplicationContext(),ListeCapteur.class);
                startActivity(intent);
                break;

            case R.id.listPassage :
                intent = new Intent(getApplicationContext(),ListeofPassage.class);
                startActivity(intent);
                break;

            case R.id.Logout :
                intent = new Intent(getApplicationContext(),LoginPersonne.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void AddCapture(View view) {
        String URL ="http://192.168.1.7:8080/captures";
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        JSONObject jsonBody = new JSONObject();

        try {
            jsonBody.put("serialNumber",serialNumber.getText().toString());

            final String mRequestBody = jsonBody.toString();

            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.i("LOG_RESPONSE", response);
                    Toast.makeText(AddCaptureActivity.this, "Le Campteur Blu Bien Ajouter", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(),ListeCapteur.class);
                    startActivity(intent);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("LOG_RESPONSE", error.toString());
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() throws AuthFailureError {
                    try {
                        return mRequestBody == null ? null : mRequestBody.getBytes("utf-8");
                    } catch (UnsupportedEncodingException e) {
                        VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s", mRequestBody, "utf-8");
                        return null;
                    }
                }
                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };
            requestQueue.add(stringRequest);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}