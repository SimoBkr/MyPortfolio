package com.example.ronde;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MyNotification extends AppCompatActivity {

    private NotificationManagerCompat notificationManagerCompat;

    private EditText edittile ;
    private EditText editmessage ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_notification);

        notificationManagerCompat = NotificationManagerCompat.from(this);
        edittile = findViewById(R.id.texttitle);
        editmessage = findViewById(R.id.tetxmessage);
    }

    public void channele1(View view) {

        String title = edittile.getText().toString();
        String message  = editmessage.getText().toString();
        Notification notification = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.ic_one)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .build();

        notificationManagerCompat.notify(1,notification);

    }

}