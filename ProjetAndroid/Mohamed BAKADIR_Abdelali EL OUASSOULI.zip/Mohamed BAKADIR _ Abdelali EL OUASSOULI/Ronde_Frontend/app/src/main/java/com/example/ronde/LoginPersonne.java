package com.example.ronde;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.ronde.model.Personne;
import com.example.ronde.model.Planning;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class LoginPersonne extends AppCompatActivity {
    private static final  String TAG ="LoginPersonne";
    private EditText editPassword ,editEmail;
    private Button btnLogin;
    private DataHelper dataHelper;

    private Boolean isConnected = false ;
    private WifiManager wifiManager ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_personne);
        initView();

        isConnected = isNetworkAvailable();

        Toast.makeText(this, isConnected+"", Toast.LENGTH_SHORT).show();

        dataHelper = new DataHelper(this);

    }

    public void initView() {
        editEmail = findViewById(R.id.InputEmail);
        editPassword = findViewById(R.id.InputPassword);
    }

    public void Loginn(View view) {

        if(isConnected == true) {

            String URL = "http://192.168.1.7:8080/personnes/search?email="+editEmail.getText().toString();

            JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, URL, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {

                    try{
                        for(int i=0;i<response.length();i++){
                            JSONObject personne = response.getJSONObject(i);
                            String email = personne.getString("email");
                            String password = personne.getString("password");
                            String role = personne.getString("role");
                            if(email.equalsIgnoreCase(editEmail.getText().toString()) && password.equals(editPassword.getText().toString())){
                                if(role.toString().equalsIgnoreCase("Admin")) {
                                    SQLiteDatabase base  = dataHelper.getWritableDatabase();
                                    ContentValues contentValues = new ContentValues();

                                    if(editEmail.getText().toString()!="" && editPassword.getText().toString()!=""){
                                        contentValues.put(DataHelper.EMAIL,editEmail.getText().toString());
                                        contentValues.put(DataHelper.PASSWORD,editPassword.getText().toString());

                                        base.insert(DataHelper.LOGIN_TABLE_NAME,null,contentValues);
                                        base.close();
                                        Intent intent = new Intent(getApplicationContext(),ListeofPlannings.class);
                                        startActivity(intent);
                                    }
                                } else{
                                    JSONArray planningsofagent =  personne.getJSONArray("plannings");

                                    String ListPlanning_name ="";
                                    String concat ="";
                                    String Listdates ="";
                                    String Listhoraire ="";


                                    Personne myagent = new Personne();
                                    myagent.setId(personne.getInt("id"));
                                    myagent.setLastName(personne.getString("firstName"));
                                    myagent.setFirstName(personne.getString("lastName"));
                                    myagent.setEmail(personne.getString("email"));
                                    myagent.setPassword(personne.getString("password"));
                                    myagent.setRole(personne.getString("role"));
                                    myagent.setDateRecruit(personne.getString("dateRecruit"));


                                    for (int k =0 ; k<planningsofagent.length();k++) {

                                        JSONObject plan = planningsofagent.getJSONObject(k);

                                        if(ListPlanning_name==""){
                                            ListPlanning_name = ListPlanning_name+concat+plan.getString("namePlanning");
                                            Listdates = Listdates+concat+plan.getString("datePlanning");
                                            Listhoraire = Listhoraire+concat+plan.getString("horaire");
                                        }else {
                                            concat = "_";
                                            ListPlanning_name = ListPlanning_name+concat+plan.getString("namePlanning");
                                            Listdates = Listdates+concat+plan.getString("datePlanning");
                                            Listhoraire = Listhoraire+concat+plan.getString("horaire");
                                        }

                                                Log.d("Planing"+k+"",ListPlanning_name.toString());

                                    }
                                    Intent intent = new Intent(getApplicationContext(),PlanningofAgent.class);
                                    intent.putExtra("Planningofagent",ListPlanning_name.toString());
                                    intent.putExtra("datesofagents",Listdates.toString());
                                    intent.putExtra("Listhoraire",Listhoraire.toString());
                                    intent.putExtra("myagent",myagent);
                                    startActivity(intent);
                                }
                            }else
                                Toast.makeText(LoginPersonne.this, "Password Or Login Incorrect", Toast.LENGTH_SHORT).show();
                        }
                    }catch (JSONException e){
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    error.printStackTrace();
                }
            });
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(jsonArrayRequest);

        }else{

            SQLiteDatabase baserecuper =  dataHelper.getReadableDatabase();

            String Requete = "email = '"+editEmail.getText().toString()+"' And "+"password ='"+editPassword.getText().toString()+"'";
            Cursor Logins = baserecuper.query(DataHelper.LOGIN_TABLE_NAME,new String[]{DataHelper.EMAIL,DataHelper.PASSWORD},
                    Requete,
                    null ,
                    null,
                    null,
                    null);

            while (Logins.moveToNext())
            {
                String Emaill = Logins.getString(0);
                String Passworddd = Logins.getString(1);
                if(Emaill.equalsIgnoreCase(editEmail.getText().toString()) &&
                        Passworddd.equalsIgnoreCase(editPassword.getText().toString())){
                    Intent intent = new Intent(getApplicationContext(),activity_planning.class);
                    startActivity(intent);
                }
            }
            baserecuper.close();
        }

    }

    private Boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    public Boolean isWifiConnected(){
        if(isNetworkAvailable()){
            ConnectivityManager cm
                    = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            return (cm.getActiveNetworkInfo().getType() == ConnectivityManager.TYPE_WIFI);
        }
        return false;
    }

    public Boolean isEthernetConnected(){
        if(isNetworkAvailable()){
            ConnectivityManager cm
                    = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            return (cm.getActiveNetworkInfo().getType() == ConnectivityManager.TYPE_ETHERNET);
        }
        return false;
    }
}
