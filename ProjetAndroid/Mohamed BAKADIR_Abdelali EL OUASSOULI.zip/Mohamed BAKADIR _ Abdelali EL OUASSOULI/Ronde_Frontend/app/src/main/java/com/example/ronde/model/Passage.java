package com.example.ronde.model;

public class Passage {


    private String id;
    private String capteur;
    private String date;


    public Passage() {
    }

    public Passage(String id, String capteur, String date) {
        this.id = id;
        this.capteur = capteur;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCapteur() {
        return capteur;
    }

    public void setCapteur(String capteur) {
        this.capteur = capteur;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
