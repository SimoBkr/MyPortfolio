package com.example.ronde;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.ronde.model.Passage;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ListeofPlannings extends AppCompatActivity {

    Landscape landscape ;
    Passage Mypassage ;
    ArrayList<Landscape> dataList ;
    List<Passage> dataListPassages ;
     private Toolbar toolbar;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listeof_plannings);

    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpRecycleView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        Intent intent ;
        switch (item.getItemId()){

            case R.id.HomeItem :
                intent = new Intent(getApplicationContext(),ListeofPlannings.class);
                startActivity(intent);
                break;

                case R.id.AddagentItem :
                intent = new Intent(getApplicationContext(),AddPersonne.class);
                startActivity(intent);
                break;

            case R.id.addplanningtoagentItem :
                intent = new Intent(getApplicationContext(),activity_planning.class);
                startActivity(intent);
                break;

            case R.id.addcapture :
                intent = new Intent(getApplicationContext(),AddCaptureActivity.class);
                startActivity(intent);
                break;

             case R.id.cap :
                intent = new Intent(getApplicationContext(),ListeCapteur.class);
                startActivity(intent);
                break;

                case R.id.listPassage :
                intent = new Intent(getApplicationContext(),ListeofPassage.class);
                startActivity(intent);
                break;

                case R.id.Logout :
                intent = new Intent(getApplicationContext(),LoginPersonne.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setUpRecycleView() {
        String URL = "http://192.168.1.7:8080/personnes/search?role=Agent";
        dataList = new ArrayList<>();
        dataListPassages = new ArrayList<>();
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, URL, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int[] images = {R.drawable.man};
                for(int i=0;i<response.length();i++){
                    landscape = new Landscape();
                    JSONObject personne = null;

                    try {
                        JSONArray allpassageofagent = null;
                        personne = response.getJSONObject(i);
                        String firstName = personne.getString("firstName");
                        String lastName = personne.getString("lastName");
                        String role = personne.getString("role");
                        int id = personne.getInt("id");
                        String date_rec = personne.getString("dateRecruit");
                        String password = personne.getString("password");
                        String email = personne.getString("email");

                       // Gson gson = new Gson();

                        allpassageofagent = personne.getJSONArray("passages");
//                        for(int k=0 ; k<allpassageofagent.length();k++) {
//                            Passage passage1 = new Passage();
//                            Mypassage = new Passage();

//                           passage1 = gson.fromJson(allpassageofagent.get(k).toString(),Passage.class);


                           //passage1.setId_agent(personne.getInt("id"));
                           // Mypassage = new Passage();
//                           passage1 = new Passage(passage1.getId(),passage1.getCapteur().toString(),passage1.getDate());
                           // Toast.makeText(ListeofPlannings.this, Mypassage.getId()+"", Toast.LENGTH_SHORT).show();

//                            Mypassage.setId(passage1.getId()+"");
//                            Mypassage.setDate(passage1.getDate().toString());
//                            Mypassage.setCapteur(passage1.getCapteur().toString());

//                            Mypassage = new Passage(Mypassage.getId(),Mypassage.getCapteur(),Mypassage.getDate());
//
//                            Toast.makeText(ListeofPlannings.this, Mypassage.getId()+"", Toast.LENGTH_SHORT).show();
//                            Toast.makeText(ListeofPlannings.this, Mypassage.getCapteur(), Toast.LENGTH_SHORT).show();
//                            Toast.makeText(ListeofPlannings.this, Mypassage.getDate(), Toast.LENGTH_SHORT).show();
//                             dataListPassages.add(Mypassage);

//                            Toast.makeText(ListeofPlannings.this, passage1.toString(), Toast.LENGTH_SHORT).show();
//                            Toast.makeText(ListeofPlannings.this, passage1.getCapteur().toString(), Toast.LENGTH_SHORT).show();
//                            Toast.makeText(ListeofPlannings.this, passage1.getDate(), Toast.LENGTH_SHORT).show();
//                            Toast.makeText(ListeofPlannings.this, passage1.getId()+"", Toast.LENGTH_SHORT).show();
//                            Toast.makeText(ListeofPlannings.this, personne.getInt("id")+"", Toast.LENGTH_SHORT).show();

//                        }

                        landscape.setImageID(images[0]);
                        landscape.setTitle(firstName+" "+lastName);
                        landscape.setDesciption(role);
                        landscape.setId(id);
                        landscape.setFirst_name(firstName);
                        landscape.setLast_name(lastName);
                        landscape.setDate_rec(date_rec);
                        landscape.setPassword(password);
                        landscape.setEmail(email);
                        landscape.setRole(role);
                        landscape.setListPassage(allpassageofagent);
                        //landscape.setListPassage(all_passages);
//
//
                        dataList.add(landscape);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

               RecyclerView recyclerViewww = (RecyclerView) findViewById(R.id.recycleView);
               RecyclerAdapter adapter  = new RecyclerAdapter(getApplicationContext(),dataList);
               recyclerViewww.setAdapter(adapter);

                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
                linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                recyclerViewww.setLayoutManager(linearLayoutManager);

                recyclerViewww.setItemAnimator(new DefaultItemAnimator());

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                    error.printStackTrace();
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }
}
