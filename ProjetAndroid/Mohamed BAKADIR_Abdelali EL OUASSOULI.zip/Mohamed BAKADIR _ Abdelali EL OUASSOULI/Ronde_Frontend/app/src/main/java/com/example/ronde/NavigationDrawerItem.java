package com.example.ronde;

import java.util.ArrayList;
import java.util.List;

public class NavigationDrawerItem {

    private String title ;
    private int imageId ;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public static List<NavigationDrawerItem> getData() {
        NavigationDrawerItem navigationDrawerItem = new NavigationDrawerItem();;
        List<NavigationDrawerItem> dataList = new ArrayList<NavigationDrawerItem>();

        int[] imageIds = getImage();
        String[] titles = getTitles();

        for (int i = 0 ; i<titles.length ; i++) {
            navigationDrawerItem.setImageId(imageIds[i]);
            navigationDrawerItem.setTitle(titles[i]);
            dataList.add(navigationDrawerItem);
        }
        return dataList;
    }

    private static int[] getImage() {
        return new int[] {
                R.drawable.ic_adduser , R.drawable.delete
        };
    }


    private static String[] getTitles() {
        return new String[] {
                "Add User" , "Delete User"
        };
    }
}
