package com.example.ronde;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ronde.model.MySingleton;
import com.example.ronde.model.Personne;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static com.example.ronde.R.*;


public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_ACCESS_COARSE_LOCATION  =1 ;
    public static final int REQUEST_ENABLE_BLE  =11 ;
    private ListView deviceliste;
    private ImageButton btnscan ;
    private BluetoothAdapter bluetoothAdapter;
    private ArrayAdapter<String> listAdapter ;
    private Personne p ;
    private  String heure;
    private ArrayList<String> listAdresses;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_main);

        Intent intent = getIntent();
        p = intent.getParcelableExtra("myagentfinal");


        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        deviceliste = findViewById(id.liste);
        btnscan  = findViewById(id.scann);

        listAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        deviceliste.setAdapter(listAdapter);

        checkBluetoothState();


        registerReceiver(devicesFoundReceiver, new IntentFilter(BluetoothDevice.ACTION_FOUND));
        registerReceiver(devicesFoundReceiver, new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_STARTED));
        registerReceiver(devicesFoundReceiver, new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED));


        btnscan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bluetoothAdapter!=null && bluetoothAdapter.isEnabled()) {
                    if(checkCoarseLocationPermission()){
                        listAdapter.clear();
                        bluetoothAdapter.startDiscovery();
                    }
                }else {
                    checkBluetoothState();
                }
            }
        });


    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(devicesFoundReceiver);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_all,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        Intent intent ;
        switch (item.getItemId()){

            case R.id.HomeItem :
                intent = new Intent(getApplicationContext(),PlanningofAgent.class);
                startActivity(intent);
                break;

            case R.id.mypassage :
                intent = new Intent(getApplicationContext(),ListeofPassage.class);
                startActivity(intent);
                break;

            case R.id.Logout :
                intent = new Intent(getApplicationContext(),LoginPersonne.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private boolean checkCoarseLocationPermission() {

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED){

            ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.ACCESS_COARSE_LOCATION},
                    REQUEST_ACCESS_COARSE_LOCATION);
            return false ;
        }else{
            return true;
        }
    }

    private void checkBluetoothState() {
        if(bluetoothAdapter ==null) {
            Toast.makeText(this, "Ble is not supported on your device ", Toast.LENGTH_SHORT).show();
        }else {
            if(bluetoothAdapter.isEnabled()) {
                if(bluetoothAdapter.isDiscovering()){
                    //Toast.makeText(this, "Device discovering process...", Toast.LENGTH_SHORT).show();
                    btnscan.setImageResource(drawable.ic_blesearshing);
                }else {
                    Toast.makeText(this, "Ble is ennabled", Toast.LENGTH_SHORT).show();
                    btnscan.setEnabled(true);
                }
            } else {
                Toast.makeText(this, "You need to enable Bluetooth", Toast.LENGTH_SHORT).show();
                Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableIntent,REQUEST_ENABLE_BLE);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_ENABLE_BLE) {
            checkBluetoothState();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode){
            case REQUEST_ACCESS_COARSE_LOCATION :
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Access coarse location allowed", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Access coarse location forbidden", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    private final BroadcastReceiver devicesFoundReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            listAdresses = new ArrayList<String>();
            if(BluetoothDevice.ACTION_FOUND.equals(action)){
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if(device!=null) {
                    listAdapter.add(device.getName()+ "\n" +device.getAddress());
                    listAdresses.add(device.getAddress());
                }
            }else if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)){

                btnscan.setImageResource(drawable.ic_blenosearshibg);
            } else if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(action)){
                btnscan.setImageResource(drawable.ic_blesearshing);
            }
        }
    };


    public void endWork(View view) {
        String URL = "http://192.168.1.7:8080/passages";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        Date d = new Date();
        heure = simpleDateFormat.format(d).toString() ;

      //  Toast.makeText(this,p.getDateRecruit().toString(), Toast.LENGTH_SHORT).show();

            JSONObject jsonObject = new JSONObject();
            JSONObject jsonObjectagent = new JSONObject();
        try {
            jsonObjectagent.put("id",p.getId());
            jsonObjectagent.put("firstName",p.getFirstName().toString());
            jsonObjectagent.put("lastName",p.getLastName().toString());
            jsonObjectagent.put("email",p.getEmail().toString());
            jsonObjectagent.put("password",p.getPassword().toString());
            jsonObjectagent.put("dateRecruit",p.getDateRecruit());
            jsonObjectagent.put("role",p.getRole().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Toast.makeText(this, listAdapter.getCount()+"", Toast.LENGTH_SHORT).show();


//        for (int i =0 ;i< listAdresses.size();i++) {
//                try {
//                    String nameAdresse [] ;
//                    nameAdresse = listAdapter.getItem(i).split("\n");
//                    jsonObject.put("date",heure.toString());
//                    jsonObject.put("agent",jsonObjectagent);
//                    jsonObject.put("capteur",nameAdresse[]);
////                    jsonObject.put("capteur",listAdresses.get(i).toString());
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//            }

        for (int i =0 ;i< listAdapter.getCount();i++) {
            try {
                String nameAdresse [] ;
                nameAdresse = listAdapter.getItem(i).split("\n");
                jsonObject.put("date",heure.toString());
                jsonObject.put("agent",jsonObjectagent);
                jsonObject.put("capteur",nameAdresse[1].toString());
//                    jsonObject.put("capteur",listAdresses.get(i).toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, URL, jsonObject, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        MySingleton.getInstance(this).addToRequestQueue(jsonObjectRequest);
    }
}