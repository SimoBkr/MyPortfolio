package com.example.ronde.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class Personne implements Parcelable {

    private int Id;
    private String firstName ;
    private String lastName;
    private String email ;
    private String password;
    private String dateRecruit ;
    private String role ;
    private List<Planning> plannings ;
    private List<Passage> passages ;

    public Personne() {
    }

    public Personne(int id, String firstName, String lastName, String email, String password, String dateRecruit, String role, List<Planning> plannings, List<Passage> passages) {
        Id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.dateRecruit = dateRecruit;
        this.role = role;
        this.plannings = plannings;
        this.passages = passages;
    }

    protected Personne(Parcel in) {
        Id = in.readInt();
        firstName = in.readString();
        lastName = in.readString();
        email = in.readString();
        password = in.readString();
        dateRecruit = in.readString();
        role = in.readString();
    }

    public static final Creator<Personne> CREATOR = new Creator<Personne>() {
        @Override
        public Personne createFromParcel(Parcel in) {
            return new Personne(in);
        }

        @Override
        public Personne[] newArray(int size) {
            return new Personne[size];
        }
    };

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDateRecruit() {
        return dateRecruit;
    }

    public void setDateRecruit(String dateRecruit) {
        this.dateRecruit = dateRecruit;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public List<Planning> getPlannings() {
        return plannings;
    }

    public void setPlannings(List<Planning> plannings) {
        this.plannings = plannings;
    }

    public List<Passage> getPassages() {
        return passages;
    }

    public void setPassages(List<Passage> passages) {
        this.passages = passages;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(Id);
        dest.writeString(firstName);
        dest.writeString(lastName);
        dest.writeString(email);
        dest.writeString(password);
        dest.writeString(dateRecruit);
        dest.writeString(role);
    }
}
