package com.example.ronde;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ronde.model.Personne;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AddPersonne extends AppCompatActivity {

    private EditText EditlastName , EditfirstName ,EditTextDate,EditTextpassword ,email;

    private TextView textRole ;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_personne);
        initView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        Intent intent ;
        switch (item.getItemId()){

            case R.id.HomeItem :
                intent = new Intent(getApplicationContext(),ListeofPlannings.class);
                startActivity(intent);
                break;

            case R.id.AddagentItem :
                intent = new Intent(getApplicationContext(),AddPersonne.class);
                startActivity(intent);
                break;

            case R.id.addplanningtoagentItem :
                intent = new Intent(getApplicationContext(),activity_planning.class);
                startActivity(intent);
                break;

            case R.id.addcapture :
                intent = new Intent(getApplicationContext(),AddCaptureActivity.class);
                startActivity(intent);
                break;

            case R.id.cap :
                intent = new Intent(getApplicationContext(),ListeCapteur.class);
                startActivity(intent);
                break;

            case R.id.listPassage :
                intent = new Intent(getApplicationContext(),ListeofPassage.class);
                startActivity(intent);
                break;

            case R.id.Logout :
                intent = new Intent(getApplicationContext(),LoginPersonne.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void  initView()
    {
        EditfirstName = findViewById(R.id.editfirstName);
        EditlastName = findViewById(R.id.editlastName);
        email = findViewById(R.id.editEmail);
        EditTextDate = findViewById(R.id.editTextDate);
        EditTextpassword = findViewById(R.id.editTextpassword);
        textRole = findViewById(R.id.textRole);
    }

    public void AddPersonne(View view) {

    String URL = "http://192.168.1.7:8080/personnes";
    RequestQueue requestQueue = Volley.newRequestQueue(this);
    JSONObject jsonBody = new JSONObject();
        try {
        jsonBody.put("firstName",EditfirstName.getText().toString());
        jsonBody.put("lastName",EditlastName.getText().toString());
        jsonBody.put("email",email.getText().toString());
        jsonBody.put("password",EditTextpassword.getText().toString());
        jsonBody.put("dateRecruit",EditTextDate.getText().toString());
        jsonBody.put("role",textRole.getText().toString());

        final String mRequestBody = jsonBody.toString();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("LOG_RESPONSE", response);

                if(response.isEmpty() == false) {
                    Toast.makeText(AddPersonne.this, "Agent "+EditfirstName.getText().toString()+" "+EditlastName.getText().toString()+" Bien Ajouter .", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(),ListeofPlannings.class);
                    startActivity(intent);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("LOG_RESPONSE", error.toString());
            }
        }) {
            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }

            @Override
            public byte[] getBody() throws AuthFailureError {
                try {
                    return mRequestBody == null ? null : mRequestBody.getBytes("utf-8");
                } catch (UnsupportedEncodingException e) {
                    VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s", mRequestBody, "utf-8");
                    return null;
                }
            }
            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                String responseString = "";
                if (response != null) {
                    responseString = String.valueOf(response.statusCode);
                }
                return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
            }
        };
        requestQueue.add(stringRequest);
    } catch (JSONException e) {
        e.printStackTrace();
    }

}
}
