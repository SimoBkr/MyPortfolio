package com.example.ronde;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.ronde.model.Capteur;
import com.example.ronde.model.Personne;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ListeCapteur extends AppCompatActivity {

    Landscape landscapeee ;
    ArrayList<Landscape> dataListeee ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_capteur);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpRecycleView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        Intent intent ;
        switch (item.getItemId()){

            case R.id.HomeItem :
                intent = new Intent(getApplicationContext(),ListeofPlannings.class);
                startActivity(intent);
                break;

            case R.id.AddagentItem :
                intent = new Intent(getApplicationContext(),AddPersonne.class);
                startActivity(intent);
                break;

            case R.id.addplanningtoagentItem :
                intent = new Intent(getApplicationContext(),activity_planning.class);
                startActivity(intent);
                break;

            case R.id.addcapture :
                intent = new Intent(getApplicationContext(),AddCaptureActivity.class);
                startActivity(intent);
                break;

            case R.id.cap :
                intent = new Intent(getApplicationContext(),ListeCapteur.class);
                startActivity(intent);
                break;

            case R.id.listPassage :
                intent = new Intent(getApplicationContext(),ListeofPassage.class);
                startActivity(intent);
                break;

            case R.id.Logout :
                intent = new Intent(getApplicationContext(),LoginPersonne.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setUpRecycleView() {
        String URL = "http://192.168.1.7:8080/captures";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, URL, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                dataListeee = new ArrayList<>();

                JSONObject capteur = null;
                for(int i=0 ; i< response.length();i++){
                    landscapeee = new Landscape();
                    try {
                        capteur = response.getJSONObject(i);
                        int[] images = {R.drawable.capteur};
                        landscapeee.setImageID(images[0]);
                        landscapeee.setTitle(capteur.getString("serialNumber").toString());
                        landscapeee.setDesciption("Bien Installer");
                        landscapeee.setId(capteur.getInt("id"));

                        dataListeee.add(landscapeee);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

               RecyclerView myrec = (RecyclerView) findViewById(R.id.recycleViewcapteur);
               RecyclerAdapterCapteur mycrecycapteur = new RecyclerAdapterCapteur(getApplicationContext(),dataListeee);
                myrec.setAdapter(mycrecycapteur);

               LinearLayoutManager linearm = new LinearLayoutManager(getApplicationContext());
                linearm.setOrientation(LinearLayoutManager.VERTICAL);
                myrec.setLayoutManager(linearm);

                myrec.setItemAnimator(new DefaultItemAnimator());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
       }

}