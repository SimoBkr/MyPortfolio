package com.example.ronde;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ronde.model.Personne;

import java.util.List;

public class RecyclerAdapterPassage extends RecyclerView.Adapter<RecyclerAdapterPassage.MyViewHolders> {

        private List<Landscape> mDataa ;
        private LayoutInflater mInflater;
        private Context context;

    public RecyclerAdapterPassage(Context context , List<Landscape> data) {
        this.mDataa = data;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolders onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Log.d("Simo","onCreateViewHolder");
        View view = mInflater.inflate(R.layout.list_item_passage,parent,false);
        MyViewHolders holder = new MyViewHolders(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolders holder, int position) {
        Log.d("Simo","onBindeViewHolder"+position);
        Landscape currentObj = mDataa.get(position);
        holder.setData(currentObj,position);
    }

    @Override
    public int getItemCount() {
        return mDataa.size();
    }

    class MyViewHolders extends RecyclerView.ViewHolder {
        TextView title , description;
        ImageView imgProfile ,imageble;
        int position;
        Landscape current ;

        public MyViewHolders( View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.titlepassage);
            description = itemView.findViewById(R.id.descriptiopassage);
            imgProfile = itemView.findViewById(R.id.imgProfilpassage);
            imageble = itemView.findViewById(R.id.imgble);
        }


        public void setData(Landscape current , int position) {
            this.title.setText(current.getTitle());
            this.description.setText(current.getDesciption());
            this.imgProfile.setImageResource(current.getImageID());
            this.position = position;
            this.current = current;
        }


    }

}



