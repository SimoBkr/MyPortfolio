package com.ronde.Ronde.controller;

import com.ronde.Ronde.model.Planning;
import com.ronde.Ronde.service.PlanningRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.bind.annotation.*;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
public class PlanningController {

    @Autowired
    PlanningRepository planningRepository;


    @GetMapping("/plannings")
    Iterable<Planning> GetPlanning() {
        return  planningRepository.findAll();
    }

    @GetMapping("/plannings/{idPlanning}")
    Optional<Planning> GetPlanning(@PathVariable Long idPlanning) {
        return  planningRepository.findById(idPlanning);
    }

    @GetMapping("/plannings/search")
    List<Planning> GetPlanningNoRealise(@RequestParam(value ="checked_planning") String checked_planning ,
                                        @RequestParam(value ="date_planning") String date_planning)
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        date_planning = simpleDateFormat.format(date);
        System.out.println(date_planning);
        return  planningRepository.findByCheckedPlanningAndDatePlanningEquals(checked_planning,date_planning);
    }

    @PostMapping("/plannings")
    Planning AddPlanning(@RequestBody Planning planning) {
        return planningRepository.save(planning);
    }


    @PutMapping("/plannings")
    Planning UpdatePlanning(@RequestBody Planning planning){
        return planningRepository.save(planning);
    }

    @DeleteMapping("/plannings/{idPlanning}")
    void DeletePlanning(@PathVariable Long idPlanning){
        planningRepository.deleteById(idPlanning);
    }

}
