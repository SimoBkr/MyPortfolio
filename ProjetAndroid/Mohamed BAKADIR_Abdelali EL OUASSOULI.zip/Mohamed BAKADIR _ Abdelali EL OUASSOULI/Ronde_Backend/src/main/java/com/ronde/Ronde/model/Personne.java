package com.ronde.Ronde.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity
public class Personne {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    private String firstName;

    private String lastName;

    private String email;

    private String password;

    private String dateRecruit;

    private String role;

    @OneToMany(mappedBy = "personne" , cascade = CascadeType.ALL)
    private List<Planning> plannings;

    @JsonIgnoreProperties("agent")
    @OneToMany(mappedBy =  "agent" , cascade =  CascadeType.ALL)
    private List<Passage> passages;

    public Personne(String firstName, String lastName, String email, String password, String dateRecruit, String role) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.dateRecruit = dateRecruit;
        this.role = role;
    }

    public Personne(Long id, String firstName, String lastName, String email, String password, String dateRecruit, String role, List<Planning> plannings, List<Passage> passages) {
        Id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.dateRecruit = dateRecruit;
        this.role = role;
        this.plannings = plannings;
        this.passages = passages;
    }

    public List<Passage> getPassages() {
        return passages;
    }

    public void setPassages(List<Passage> passages) {
        this.passages = passages;
    }

    public Personne() {
    }

    public Personne(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDateRecruit() {
        return dateRecruit;
    }

    public void setDateRecruit(String dateRecruit) {
        this.dateRecruit = dateRecruit;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public List<Planning> getPlannings() {
        return plannings;
    }

    public void setPlannings(List<Planning> plannings) {
        this.plannings = plannings;
    }
}