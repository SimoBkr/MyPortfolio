package com.ronde.Ronde.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.ArrayList;

@Entity
public class Planning {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    private String namePlanning;

    private String datePlanning;

    private String horaire;

    private String checkedPlanning;


    public Planning(Long id, String namePlanning, String datePlanning, String horaire, String checkedPlanning, Personne personne) {
        Id = id;
        this.namePlanning = namePlanning;
        this.datePlanning = datePlanning;
        this.horaire = horaire;
        this.checkedPlanning = checkedPlanning;
        this.personne = personne;
    }

    public String getCheckedPlanning() {
        return checkedPlanning;
    }

    public void setCheckedPlanning(String checkedPlanning) {
        this.checkedPlanning = checkedPlanning;
    }

    @ManyToOne
    @JsonIgnoreProperties("plannings")
    private Personne personne;

    public Planning() {

    }

    public Planning(String namePlanning) {
        this.namePlanning = namePlanning;
    }

    public Planning(Long id, String namePlanning, String datePlanning, String horaire, Personne personne) {
        Id = id;
        this.namePlanning = namePlanning;
        this.datePlanning = datePlanning;
        this.horaire = horaire;
        this.personne = personne;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getNamePlanning() {
        return namePlanning;
    }

    public void setNamePlanning(String namePlanning) {
        this.namePlanning = namePlanning;
    }

    public String getDatePlanning() {
        return datePlanning;
    }

    public void setDatePlanning(String datePlanning) {
        this.datePlanning = datePlanning;
    }

    public String getHoraire() {
        return horaire;
    }

    public void setHoraire(String horaire) {
        this.horaire = horaire;
    }

    public Personne getPersonne() {
        return personne;
    }

    public void setPersonne(Personne personne) {
        this.personne = personne;
    }
}
