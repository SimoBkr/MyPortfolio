package com.ronde.Ronde.controller;

import com.ronde.Ronde.model.AgentToken;
import com.ronde.Ronde.model.Personne;
import com.ronde.Ronde.service.AgentTokenRepository;
import com.ronde.Ronde.service.PersonneRepository;
import jdk.internal.agent.Agent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class AgentTokenController {

    @Autowired
    AgentTokenRepository agentTokenRepository;

    @GetMapping("/Agenttokens")
    Iterable<AgentToken> GetAgent() {
        return  agentTokenRepository.findAll();
    }

    @GetMapping("/Agenttokens/{Id}")
    Optional<AgentToken> GetAgent(@PathVariable Long Id) {
        return  agentTokenRepository.findById(Id);
    }

    @GetMapping("/Agenttokens/search")
    Iterable<AgentToken> findById_token(@RequestParam(value ="id_token") String id_token) {
            return agentTokenRepository.findByIdToken(id_token);
    }

    @GetMapping("/Agenttokens/searchh")
    String findByIdAgent(@RequestParam(value ="id_agent") int id_agent) {
            return agentTokenRepository.findByIdAgent(id_agent);
    }

    @PostMapping("/Agenttokens")
    AgentToken AddAgentToken(@RequestBody AgentToken agentToken) {
        return agentTokenRepository.save(agentToken);
    }

    @PutMapping("/Agenttokens")
    AgentToken UpdateAgentToken(@RequestBody AgentToken agentToken){
        return agentTokenRepository.save(agentToken);
    }

    @DeleteMapping("/Agenttokens/{idAgentToken}")
    void DeleteAgentToken(@PathVariable Long idAgentToken){
        agentTokenRepository.deleteById(idAgentToken);
    }
}


