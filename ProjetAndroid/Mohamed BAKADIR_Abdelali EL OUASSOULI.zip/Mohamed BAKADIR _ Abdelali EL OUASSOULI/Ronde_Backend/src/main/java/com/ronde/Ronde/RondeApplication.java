package com.ronde.Ronde;

import com.ronde.Ronde.model.Personne;
import com.ronde.Ronde.model.Planning;
import com.ronde.Ronde.service.PersonneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class RondeApplication  implements  CommandLineRunner{

	@Autowired
	PersonneRepository personneRepository ;

	public static void main(String[] args) {
		SpringApplication.run(RondeApplication.class, args);
	}


	@Override
	public void run(String... args) throws Exception {

		Personne personne = new Personne("Mohamed","Bakadir","m@m","m@m","24/08/2020","Admin");

		personneRepository.save(personne);

	}
}
