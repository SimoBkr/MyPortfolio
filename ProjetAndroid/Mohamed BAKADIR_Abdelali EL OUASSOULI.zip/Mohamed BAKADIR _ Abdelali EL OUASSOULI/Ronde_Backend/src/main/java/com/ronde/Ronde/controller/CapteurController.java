package com.ronde.Ronde.controller;

import com.ronde.Ronde.model.Capteur;
import com.ronde.Ronde.model.Personne;
import com.ronde.Ronde.service.CaptureRepository;
import com.ronde.Ronde.service.PersonneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class CapteurController {

    @Autowired
    CaptureRepository captureRepository;

    @GetMapping("/captures")
    Iterable<Capteur> GetCaptures() {
        return  captureRepository.findAll();
    }

    @GetMapping("captures/{idCapture}")
    Optional<Capteur> GetCapture(@PathVariable Long idCapture) {
        return  captureRepository.findById(idCapture);
    }

    @PostMapping("/captures")
    Capteur AddCapture(@RequestBody Capteur capteur) {
        return captureRepository.save(capteur);
    }

    @PutMapping("/captures")
    Capteur UpdateCapture(@RequestBody Capteur capteur){
        return captureRepository.save(capteur);
    }

    @DeleteMapping("captures/{idCapture}")
    void DeleteCapture(@PathVariable Long idCapture){
        captureRepository.deleteById(idCapture);
    }
}


