package com.ronde.Ronde.controller;

import com.ronde.Ronde.model.Personne;
import com.ronde.Ronde.service.PersonneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class PersonneController {

    @Autowired
    PersonneRepository personneRepository;

    @GetMapping("/personnes")
    Iterable<Personne> GetAgent() {
        return  personneRepository.findAll();
    }

    @GetMapping("/personnes/{idPersonne}")
    Optional<Personne> GetAgent(@PathVariable Long idPersonne) {
        return  personneRepository.findById(idPersonne);
    }

    @GetMapping("/personnes/search")
    Iterable<Personne> findByQueryEmail(@RequestParam(value ="email" , required = false) String email,
                                    @RequestParam(value ="role" , required = false) String role) {
        if(email != null)
            return personneRepository.findByEmail(email);
        else
            return personneRepository.findByRole(role);
    }

    @GetMapping("/personnes/searchh")
    Personne findByLastName(@RequestParam(value = "lastname") String lastName) {

        return personneRepository.findByLastName(lastName);
    }

    @PostMapping("/personnes")
    Personne AddAgent(@RequestBody Personne personne) {
        return personneRepository.save(personne);
    }

    @PutMapping("/personnes")
    Personne UpdateAgent(@RequestBody Personne personne){
        return personneRepository.save(personne);
    }

    @DeleteMapping("/personnes/{idPersonne}")
    void DeleteAgent(@PathVariable Long idPersonne){
        personneRepository.deleteById(idPersonne);
    }
}
