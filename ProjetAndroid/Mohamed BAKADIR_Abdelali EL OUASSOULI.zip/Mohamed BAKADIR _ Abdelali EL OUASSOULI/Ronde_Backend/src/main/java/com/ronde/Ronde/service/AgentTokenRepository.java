package com.ronde.Ronde.service;

import com.ronde.Ronde.model.AgentToken;
import com.ronde.Ronde.model.Capteur;
import com.ronde.Ronde.model.Personne;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;
import java.util.Optional;

@RepositoryRestResource(collectionResourceRel = "AgentToken", path = "AgentToken")
public interface AgentTokenRepository extends CrudRepository<AgentToken,Long> {

    Iterable<AgentToken> findByIdToken(String id_token);

    @Query("select DISTINCT a.idToken from AgentToken a")
    String findByIdAgent(int id_agent);
}
