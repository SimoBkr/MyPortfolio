package com.ronde.Ronde.service;

import com.ronde.Ronde.model.Planning;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PlanningRepository extends CrudRepository<Planning,Long> {

    List<Planning> findByCheckedPlanningAndDatePlanningEquals(String checked_planning ,String date_planning);

}
