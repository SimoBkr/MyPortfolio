package com.ronde.Ronde.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;

@Entity
public class Passage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;


    @ManyToOne
    private Personne agent;


    private String capteur;

    private String Date;


    public Passage() {
    }

    public Passage(Long id, Personne agent, String capteur, String date) {
        Id = id;
        this.agent = agent;
        this.capteur = capteur;
        Date = date;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public Personne getAgent() {
        return agent;
    }

    public void setAgent(Personne agent) {
        this.agent = agent;
    }

    public String getCapteur() {
        return capteur;
    }

    public void setCapteur(String capteur) {
        this.capteur = capteur;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
}
