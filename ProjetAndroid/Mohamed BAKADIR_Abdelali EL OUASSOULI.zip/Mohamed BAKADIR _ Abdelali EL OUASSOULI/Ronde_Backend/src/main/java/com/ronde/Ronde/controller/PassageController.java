package com.ronde.Ronde.controller;

import com.ronde.Ronde.model.Passage;
import com.ronde.Ronde.model.Personne;
import com.ronde.Ronde.service.PassageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class PassageController {

    @Autowired
    PassageRepository passageRepository;

    @GetMapping("/passages")
    Iterable<Passage> GetPassage() {
        return  passageRepository.findAll();
    }

    @GetMapping("/passages/{idPassage}")
    Optional<Passage> GetPassage(@PathVariable Long idPassage) {
        return  passageRepository.findById(idPassage);
    }

    @PostMapping("/passages")
    Passage AddPassage(@RequestBody Passage passage) {
        return passageRepository.save(passage);
    }

    @PutMapping("/passages")
    Passage UpdatePassage(@RequestBody Passage passage){
        return passageRepository.save(passage);
    }

    @DeleteMapping("/passages/{idPassage}")
    void DeletePassage(@PathVariable Long idPassage){
        passageRepository.deleteById(idPassage);
    }

}
