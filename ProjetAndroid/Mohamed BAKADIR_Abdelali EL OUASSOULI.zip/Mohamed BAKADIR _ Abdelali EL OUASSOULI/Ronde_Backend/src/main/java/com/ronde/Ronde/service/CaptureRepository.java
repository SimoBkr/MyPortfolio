package com.ronde.Ronde.service;

import com.ronde.Ronde.model.Capteur;
import org.springframework.data.repository.CrudRepository;

public interface CaptureRepository extends CrudRepository<Capteur,Long> {
}
